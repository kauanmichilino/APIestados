const express = require('express');
const router = express.Router();
const Estado = require('../models/Estado');

// GET /estados
router.get('/', async (req, res) => {
  try {
    const estados = await Estado.find({}, { _id: 0, __v: 0 });
    res.json(estados);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /estados/:id
router.get('/:id', async (req, res) => {
  try {
    const estado = await Estado.findOne({ id: parseInt(req.params.id) }, { _id: 0, __v: 0 });
    if (!estado) return res.status(404).json({ message: 'Estado não encontrado' });
    res.json([estado]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
