const mongoose = require('mongoose');

const estadoSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  sigla: { type: String, required: true },
  capital: { type: String, required: true },
  habitantes: { type: Number, required: true }
});

module.exports = mongoose.model('Estado', estadoSchema);
