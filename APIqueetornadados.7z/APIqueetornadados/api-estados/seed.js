const mongoose = require('mongoose');
const Estado = require('./models/Estado');

mongoose.connect('mongodb://localhost:27017/estadosdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const estados = [
  { id: 1, sigla: 'SP', capital: 'São Paulo', habitantes: 44411238 },
  { id: 2, sigla: 'BA', capital: 'Salvador', habitantes: 14850513 },
];

Estado.insertMany(estados)
  .then(() => {
    console.log('Estados inseridos com sucesso');
    mongoose.disconnect();
  })
  .catch((err) => console.log('Erro ao inserir:', err));
